import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import { runThresholdCheck } from '../../shared/thresholdRules.ts';

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) return Response.json({ error: 'Unauthorized' }, { status: 401 });

    const body = await req.json().catch(() => ({}));
    const sinceHours = Number(body.sinceHours) > 0 ? Math.min(Number(body.sinceHours), 72) : 4;

    const result = await runThresholdCheck(base44, { sinceHours });

    return Response.json({
      checked: result.checkedSensors,
      sensors_total: result.sensorsTotal,
      created: result.created,
      resolved: result.resolved,
      violations: result.violations,
      window_hours: result.windowHours,
      message: `${result.violations.length} Grenzwertüberschreitung(en) gefunden, ${result.created} neue Meldung(en) erzeugt.`,
    });
  } catch (error) {
    return Response.json({ error: error.message }, { status: 500 });
  }
}