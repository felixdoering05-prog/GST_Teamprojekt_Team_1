import { useEffect, useRef, useState } from 'react';
import { Loader2, Send } from 'lucide-react';
import { Button } from '@/components/ui/button';
import AssistantMessage from '@/components/assistant/AssistantMessage';
import { askBuildingAssistant } from '@/lib/assistantClient';

const SUGGESTION = 'Fasse die vorhandenen Messwerte und Grenzwertmeldungen dieses Gebäudes verständlich zusammen.';

/**
 * Frage- und Antwortbereich. Eingabe ist während einer laufenden Anfrage gesperrt,
 * leere Fragen werden nicht gesendet.
 */
export default function AssistantChat({ building }) {
  const [entries, setEntries] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const endRef = useRef(null);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [entries, loading]);

  const send = async (question) => {
    const text = String(question || '').trim();
    if (!text || loading || !building) return;

    setEntries((prev) => [...prev, { role: 'user', text, id: crypto.randomUUID() }]);
    setInput('');
    setLoading(true);

    const result = await askBuildingAssistant({ buildingId: building.id, question: text });

    setEntries((prev) => [
      ...prev,
      result.ok
        ? { role: 'assistant', data: result.data, id: crypto.randomUUID() }
        : { role: 'error', message: result.message, hint: result.hint, id: crypto.randomUUID() },
    ]);
    setLoading(false);
  };

  const handleSubmit = (event) => {
    event.preventDefault();
    send(input);
  };

  return (
    <div className="surface flex flex-col">
      <div className="border-b border-border px-4 py-3 sm:px-5">
        <h3 className="font-heading text-sm font-semibold text-foreground">Frage zum Gebäude</h3>
        <p className="text-[11px] text-muted-foreground">
          Freigegebene Daten von {building ? building.name : '–'} · letzte 24 Stunden
        </p>
      </div>

      <div className="max-h-[520px] min-h-[180px] space-y-3 overflow-y-auto px-4 py-4 sm:px-5">
        {entries.length === 0 ? (
          <div className="rounded-xl bg-secondary/60 p-4">
            <p className="text-xs text-muted-foreground">
              Stellen Sie eine Frage zu den Messwerten und Meldungen des gewählten Gebäudes. Die Antwort nennt immer
              Gebäude und Datenzeitraum und ist als KI-generiert gekennzeichnet.
            </p>
            <button
              type="button"
              onClick={() => setInput(SUGGESTION)}
              className="mt-2 text-left text-xs font-medium text-primary underline-offset-4 hover:underline"
            >
              Vorschlag: „{SUGGESTION}“
            </button>
          </div>
        ) : null}

        {entries.map((entry) => (
          <AssistantMessage key={entry.id} entry={entry} />
        ))}

        {loading ? (
          <div className="flex items-center gap-2 rounded-2xl border border-border bg-card px-4 py-3 text-xs text-muted-foreground">
            <Loader2 className="h-4 w-4 animate-spin text-primary" />
            Antwort wird aus den freigegebenen Daten erstellt …
          </div>
        ) : null}

        <div ref={endRef} />
      </div>

      <form onSubmit={handleSubmit} className="flex flex-col gap-2 border-t border-border px-4 py-3 sm:flex-row sm:items-center sm:px-5">
        <input
          type="text"
          value={input}
          onChange={(event) => setInput(event.target.value)}
          disabled={loading || !building}
          maxLength={400}
          placeholder={building ? 'Ihre Frage zum Gebäude …' : 'Kein Gebäude ausgewählt'}
          aria-label="Frage zum Gebäude"
          className="h-10 w-full rounded-xl border border-input bg-card px-3 text-sm text-foreground shadow-sm placeholder:text-muted-foreground/70 focus:border-primary focus:outline-none focus:ring-2 focus:ring-primary/20 disabled:cursor-not-allowed disabled:opacity-60"
        />
        <Button type="submit" disabled={loading || !building || !input.trim()} className="shrink-0">
          {loading ? <Loader2 className="mr-1.5 h-4 w-4 animate-spin" /> : <Send className="mr-1.5 h-4 w-4" />}
          {loading ? 'Anfrage läuft …' : 'Senden'}
        </Button>
      </form>
    </div>
  );
}