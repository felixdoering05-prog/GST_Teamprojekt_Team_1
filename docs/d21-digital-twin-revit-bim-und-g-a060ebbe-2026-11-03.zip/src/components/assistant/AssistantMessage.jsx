import { CircleAlert, Info } from 'lucide-react';
import AssistantAnswer from '@/components/assistant/AssistantAnswer';

/** Ein Eintrag im Verlauf des Gebäude-Assistenten. */
export default function AssistantMessage({ entry }) {
  if (entry.role === 'user') {
    return (
      <div className="flex justify-end">
        <p className="max-w-[85%] rounded-2xl rounded-br-sm bg-primary px-4 py-2.5 text-sm text-primary-foreground">
          {entry.text}
        </p>
      </div>
    );
  }

  if (entry.role === 'error') {
    return (
      <div className="rounded-2xl border border-destructive/30 bg-destructive/5 p-4">
        <p className="flex items-center gap-2 text-xs font-semibold text-destructive">
          <CircleAlert className="h-4 w-4" /> Anfrage nicht möglich
        </p>
        <p className="mt-1.5 text-sm text-foreground">{entry.message}</p>
        {entry.hint ? (
          <p className="mt-2 flex items-start gap-2 rounded-xl bg-card/70 px-3 py-2 text-[11px] text-muted-foreground ring-1 ring-inset ring-border">
            <Info className="mt-0.5 h-3.5 w-3.5 shrink-0" />
            {entry.hint}
          </p>
        ) : null}
      </div>
    );
  }

  return <AssistantAnswer data={entry.data} />;
}