import { Building2, Clock, Sparkles, TriangleAlert } from 'lucide-react';
import { formatDateTime } from '@/lib/dates';

/**
 * Antwortkarte des Gebäude-Assistenten.
 * Jede Antwort wird als KI-generiert gekennzeichnet und nennt Gebäude und Datenzeitraum.
 */
export default function AssistantAnswer({ data }) {
  const quality = data.data_quality || {};
  const buildingLabel = data.building
    ? `${data.building.name}${data.building.code && data.building.code !== data.building.name ? ` (${data.building.code})` : ''}`
    : '–';

  return (
    <div className="rounded-2xl border border-cyan-200 bg-cyan-50/50 p-4">
      <div className="flex flex-wrap items-center gap-2">
        <span className="inline-flex items-center gap-1.5 rounded-full bg-cyan-700 px-2.5 py-1 text-[11px] font-semibold text-white">
          <Sparkles className="h-3 w-3" /> KI-generierte Antwort
        </span>
        <span className="text-[11px] text-muted-foreground">{formatDateTime(new Date())}</span>
      </div>

      <div className="mt-2 flex flex-wrap items-center gap-x-4 gap-y-1 text-[11px] text-muted-foreground">
        <span className="inline-flex items-center gap-1.5">
          <Building2 className="h-3.5 w-3.5" /> Gebäude: <strong className="font-medium text-foreground">{buildingLabel}</strong>
        </span>
        <span className="inline-flex items-center gap-1.5">
          <Clock className="h-3.5 w-3.5" /> Zeitraum:{' '}
          <strong className="font-medium text-foreground">
            {formatDateTime(data.period?.from)} – {formatDateTime(data.period?.to)}
          </strong>
        </span>
      </div>

      <p className="mt-3 whitespace-pre-line text-sm leading-relaxed text-foreground">{data.answer}</p>

      {data.notice ? (
        <p className="mt-3 flex items-start gap-2 rounded-xl bg-amber-50 px-3 py-2 text-[11px] text-amber-800 ring-1 ring-inset ring-amber-600/20">
          <TriangleAlert className="mt-0.5 h-3.5 w-3.5 shrink-0" />
          {data.notice}
        </p>
      ) : null}

      {quality.demo_only ? (
        <p className="mt-2 text-[11px] text-violet-700">
          Grundlage sind ausschließlich Demo-Daten ({quality.demo_measurements} von {quality.measurements} Messwerten).
        </p>
      ) : null}

      <p className="mt-3 border-t border-cyan-200/70 pt-2 text-[11px] text-muted-foreground">
        Orientierung, keine gesicherte Diagnose – fachlich prüfen. Grundlage sind die freigegebenen Daten dieses
        Gebäudes.
      </p>
    </div>
  );
}