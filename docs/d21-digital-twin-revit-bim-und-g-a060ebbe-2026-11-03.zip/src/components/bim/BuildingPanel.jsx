import { Building2 } from 'lucide-react';
import { cn } from '@/lib/utils';
import SourceBadge from '@/components/SourceBadge';

const DOT = {
  ok: 'bg-emerald-500',
  warning: 'bg-amber-500',
  critical: 'bg-red-500',
  unknown: 'bg-slate-400',
};

export default function BuildingPanel({
  buildings = [],
  activeBuilding,
  onSelectBuilding,
  floors = [],
  activeFloorId,
  onSelectFloor,
  roomCountByFloor = {},
  statusByFloor = {},
}) {
  if (!activeBuilding) {
    return null;
  }

  const facts = [
    { label: 'Standort', value: activeBuilding.site || '–' },
    { label: 'Nutzung', value: activeBuilding.usage_type || '–' },
    { label: 'Geschosse', value: activeBuilding.floors_count ? String(activeBuilding.floors_count) : '–' },
    { label: 'Bruttofläche', value: activeBuilding.gross_area_m2 ? `${activeBuilding.gross_area_m2} m²` : '–' },
  ];

  return (
    <div className="surface flex h-full flex-col p-5">
      <div className="flex items-start justify-between gap-3">
        <div className="flex min-w-0 items-start gap-3">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-cyan-50 text-cyan-700">
            <Building2 className="h-4 w-4" />
          </span>
          <div className="min-w-0">
            <p className="tabular text-[11px] font-medium text-muted-foreground">{activeBuilding.code || 'Gebäude'}</p>
            <h3 className="font-heading text-base font-semibold leading-tight text-foreground">{activeBuilding.name}</h3>
          </div>
        </div>
        <SourceBadge source={activeBuilding.source} />
      </div>

      {buildings.length > 1 ? (
        <div className="mt-4 flex flex-wrap gap-1.5">
          {buildings.map((building) => (
            <button
              key={building.id}
              type="button"
              onClick={() => onSelectBuilding(building)}
              className={cn(
                'rounded-full px-2.5 py-1 text-[11px] font-medium transition-colors',
                building.id === activeBuilding.id
                  ? 'bg-primary text-primary-foreground'
                  : 'bg-secondary text-muted-foreground hover:text-foreground',
              )}
            >
              {building.code || building.name}
            </button>
          ))}
        </div>
      ) : null}

      <dl className="mt-4 grid grid-cols-2 gap-x-3 gap-y-2.5">
        {facts.map((fact) => (
          <div key={fact.label} className="min-w-0">
            <dt className="text-[10.5px] uppercase tracking-wide text-muted-foreground">{fact.label}</dt>
            <dd className="truncate text-xs font-medium text-foreground">{fact.value}</dd>
          </div>
        ))}
      </dl>

      <div className="mt-5 flex items-center justify-between">
        <h4 className="text-xs font-semibold uppercase tracking-wide text-muted-foreground">Etagen</h4>
        <span className="text-[10.5px] text-muted-foreground">im Modell anklickbar</span>
      </div>

      <ul className="mt-2 space-y-1.5">
        {floors.map((floor) => {
          const active = floor.id === activeFloorId;
          return (
            <li key={floor.id}>
              <button
                type="button"
                onClick={() => onSelectFloor(floor.id)}
                className={cn(
                  'flex w-full items-center justify-between gap-3 rounded-xl px-2.5 py-2 text-left transition-colors',
                  active
                    ? 'bg-accent text-accent-foreground ring-1 ring-inset ring-primary/30'
                    : 'hover:bg-secondary',
                )}
              >
                <span className="flex min-w-0 items-center gap-2.5">
                  <span
                    className={cn(
                      'tabular grid h-8 w-8 shrink-0 place-items-center rounded-lg text-[10px] font-semibold',
                      active ? 'bg-primary text-primary-foreground' : 'bg-secondary text-muted-foreground',
                    )}
                  >
                    {floor.level ?? '–'}
                  </span>
                  <span className="min-w-0">
                    <span className="block truncate text-sm font-semibold leading-tight">{floor.name}</span>
                    <span className="block text-[11px] text-muted-foreground">
                      {roomCountByFloor[floor.id] || 0} Räume
                      {floor.area_m2 ? ` · ${floor.area_m2} m²` : ''}
                    </span>
                  </span>
                </span>
                <span className={cn('h-2 w-2 shrink-0 rounded-full', DOT[statusByFloor[floor.id]] || DOT.unknown)} />
              </button>
            </li>
          );
        })}
      </ul>

      <p className="mt-auto pt-4 text-[11px] leading-relaxed text-muted-foreground">
        Grundrisse entstehen aus den Raumstammdaten. Sobald das IFC-Modell verknüpft ist, ersetzen echte Bauteile diese
        schematische Darstellung.
      </p>
    </div>
  );
}