import { cn } from '@/lib/utils';
import { METRICS, formatNumber } from '@/lib/metrics';

const PLAN = { x: 68, y: 96, w: 620, depth: 128, corridor: 48 };
const PLAN_BOTTOM = PLAN.y + PLAN.depth + PLAN.corridor + PLAN.depth;

const FILL = {
  ok: '#f7fcf9',
  warning: '#fff8ec',
  critical: '#fdf0f0',
  unknown: '#f7f9fb',
};

const EDGE = {
  ok: '#8fceb0',
  warning: '#e7bd7c',
  critical: '#e2a09d',
  unknown: '#c3cfd9',
};

const clip = (text = '', width, charWidth) => {
  const max = Math.max(3, Math.floor((width - 16) / charWidth));
  return text.length > max ? `${text.slice(0, max - 1)}…` : text;
};

export default function RevitFloorPlan({
  rooms = [],
  readingsByRoom = {},
  selectedRoomId,
  onSelect,
  floorName,
  buildingCode,
  revitCount,
}) {
  if (!rooms.length) {
    return (
      <div className="grid place-items-center rounded-xl bg-secondary px-6 py-16 text-center">
        <p className="text-sm text-muted-foreground">Für dieses Geschoss sind keine Räume angelegt.</p>
      </div>
    );
  }

  const sorted = [...rooms].sort((a, b) => String(a.room_code).localeCompare(String(b.room_code), 'de'));
  const half = Math.ceil(sorted.length / 2);
  const rows = [sorted.slice(0, half), sorted.slice(half)];

  const withLayout = rows.map((row) => {
    const weights = row.map((room) => Math.sqrt(Number(room.area_m2) || 20));
    const total = weights.reduce((sum, value) => sum + value, 0) || 1;
    let offset = 0;
    return row.map((room, index) => {
      const width = (weights[index] / total) * PLAN.w;
      const item = { room, x: PLAN.x + offset, width };
      offset += width;
      return item;
    });
  });

  const areaSum = rooms.reduce((sum, room) => sum + (Number(room.area_m2) || 0), 0);

  return (
    <svg
      viewBox="0 0 760 470"
      role="img"
      aria-label={`Schematischer Grundriss ${floorName || ''} mit ${rooms.length} Räumen`}
      className="h-auto w-full min-w-[520px]"
    >
      <defs>
        <pattern id="bim-plan-grid" width="24" height="24" patternUnits="userSpaceOnUse">
          <path d="M 24 0 L 0 0 0 24" fill="none" stroke="#e8eef3" strokeWidth="1" />
        </pattern>
      </defs>

      <rect width="760" height="470" fill="#fbfdfe" />
      <rect width="760" height="470" fill="url(#bim-plan-grid)" />

      {/* Baukörper */}
      <rect
        x={PLAN.x}
        y={PLAN.y}
        width={PLAN.w}
        height={PLAN.depth * 2 + PLAN.corridor}
        fill="#ffffff"
        stroke="#33475b"
        strokeWidth="5"
      />

      {/* Flur */}
      <rect x={PLAN.x} y={PLAN.y + PLAN.depth} width={PLAN.w} height={PLAN.corridor} fill="#eef4f8" />
      <line
        x1={PLAN.x + 18}
        y1={PLAN.y + PLAN.depth + PLAN.corridor / 2}
        x2={PLAN.x + PLAN.w - 18}
        y2={PLAN.y + PLAN.depth + PLAN.corridor / 2}
        stroke="#c8d8e2"
        strokeWidth="1"
        strokeDasharray="8 7"
      />
      <text
        x={PLAN.x + PLAN.w - 12}
        y={PLAN.y + PLAN.depth + PLAN.corridor / 2 + 4}
        textAnchor="end"
        fontSize="9.5"
        fill="#8fa4b3"
        letterSpacing="2"
      >
        FLUR
      </text>

      {withLayout.map((row, rowIndex) =>
        row.map(({ room, x, width }) => {
          const entry = readingsByRoom[room.id] || { status: 'unknown', readings: {} };
          const status = entry.status || 'unknown';
          const temperature = entry.readings.temperature;
          const selected = room.id === selectedRoomId;
          const rowY = rowIndex === 0 ? PLAN.y : PLAN.y + PLAN.depth + PLAN.corridor;
          const corridorEdge = rowIndex === 0 ? rowY + PLAN.depth : rowY;
          const doorX = x + Math.min(width / 2 - 12, 26);

          return (
            <g
              key={room.id}
              role="button"
              tabIndex={0}
              aria-label={`${room.name}: Details anzeigen`}
              className="cursor-pointer focus:outline-none"
              onClick={() => onSelect(room.id)}
              onKeyDown={(event) => {
                if (event.key === 'Enter' || event.key === ' ') {
                  event.preventDefault();
                  onSelect(room.id);
                }
              }}
            >
              <rect
                x={x}
                y={rowY}
                width={width}
                height={PLAN.depth}
                fill={selected ? '#e2f1f6' : FILL[status] || FILL.unknown}
                stroke={selected ? '#066d84' : EDGE[status] || EDGE.unknown}
                strokeWidth={selected ? 3 : 1.4}
                className={cn('transition-opacity hover:opacity-80')}
              />
              <title>{`${room.room_code} · ${room.name}`}</title>

              {/* Tür zum Flur */}
              <rect x={doorX} y={corridorEdge - 2.5} width="24" height="5" fill="#ffffff" />
              <path
                d={
                  rowIndex === 0
                    ? `M ${doorX} ${corridorEdge} a 24 24 0 0 1 24 -24`
                    : `M ${doorX} ${corridorEdge} a 24 24 0 0 0 24 24`
                }
                fill="none"
                stroke="#b6c8d4"
                strokeWidth="1"
              />

              <text x={x + 10} y={rowY + 20} fontSize="9.5" fill="#7b8fa0" fontFamily="monospace">
                {room.room_code}
              </text>
              <text x={x + 10} y={rowY + 38} fontSize="11.5" fontWeight={selected ? 700 : 600} fill="#182a38">
                {clip(room.name, width, 6.6)}
              </text>
              <text x={x + 10} y={rowY + 54} fontSize="9" fill="#93a6b4">
                {clip(room.usage || 'Nutzung nicht hinterlegt', width, 5.1)}
              </text>
              <text x={x + 10} y={rowY + 70} fontSize="9.5" fill="#65798a">
                {room.area_m2 ? `${room.area_m2} m²` : '–'}
              </text>

              <circle
                cx={x + 13}
                cy={rowY + 88}
                r="3.4"
                fill={temperature ? METRICS.temperature.color : '#c3cfd9'}
                opacity={temperature ? 0.85 : 0.6}
              />
              <text x={x + 21} y={rowY + 92} fontSize="10" fill="#65798a">
                {temperature ? `${formatNumber('temperature', temperature.value)} °C` : 'keine Messwerte'}
              </text>
            </g>
          );
        }),
      )}

      {/* Schnittmarken der Außenwände */}
      <line x1={PLAN.x} y1={PLAN.y + PLAN.depth - 6} x2={PLAN.x + PLAN.w} y2={PLAN.y + PLAN.depth - 6} stroke="#33475b" strokeWidth="1.6" />
      <line
        x1={PLAN.x}
        y1={PLAN.y + PLAN.depth + PLAN.corridor + 6}
        x2={PLAN.x + PLAN.w}
        y2={PLAN.y + PLAN.depth + PLAN.corridor + 6}
        stroke="#33475b"
        strokeWidth="1.6"
      />

      {/* Nordpfeil */}
      <g transform="translate(712, 52)">
        <circle r="17" fill="#ffffff" stroke="#d3dfe8" />
        <polygon points="0,-10 5,5 0,2 -5,5" fill="#33475b" />
        <text x="0" y="-14" textAnchor="middle" fontSize="9" fontWeight="700" fill="#8fa4b3">
          N
        </text>
      </g>

      {/* Schriftfeld */}
      <line x1={PLAN.x} y1={PLAN_BOTTOM + 16} x2={PLAN.x + PLAN.w} y2={PLAN_BOTTOM + 16} stroke="#dbe5ec" strokeWidth="1" />
      <text x={PLAN.x} y={PLAN_BOTTOM + 34} fontSize="10" fill="#7b8fa0">
        {`${rooms.length} Räume · ${areaSum.toLocaleString('de-DE')} m²`}
      </text>
      <text x={PLAN.x + PLAN.w} y={PLAN_BOTTOM + 34} textAnchor="end" fontSize="10" fill="#7b8fa0">
        {`${buildingCode || 'Gebäude'} · ${floorName || 'Geschoss'} · schematischer Grundriss · Revit-IDs: ${revitCount}/${rooms.length}`}
      </text>
      <text x={PLAN.x} y={PLAN_BOTTOM + 50} fontSize="9" fill="#a3b4c1">
        Raumflächen aus den Stammdaten · Wandstärken, Türen und Flure schematisch
      </text>
    </svg>
  );
}