import { useState } from 'react';
import { CAMPUS_ATTRIBUTION, CAMPUS_BUILDINGS, CAMPUS_ROADS } from './campusGeometry';

const SCALE = 1.35;
const SKEW = 0.72;
const CX = 380;
const CY = 330;

const project = (x, y) => ({ x: CX + x * SCALE, y: CY - y * SCALE * SKEW });
const parsePoints = (value) =>
  value
    .split(' ')
    .filter(Boolean)
    .map((pair) => pair.split(',').map(Number));
const rectRing = ({ x, y, w, d }) => [
  [x, y],
  [x + w, y],
  [x + w, y + d],
  [x, y + d],
];
const heightFor = (levels) => Math.max(7, (Number(levels) || 1) * 3.2 * SCALE);
const southEdge = (ring) => Math.max(...ring.map(([x, y]) => project(x, y).y));

const STATUS_COLOR = { ok: '#10b981', warning: '#f59e0b', critical: '#ef4444', unknown: '#94a3b8' };

const TONE = {
  context: { wall: '#cdd9e2', roof: '#eef4f8', stroke: '#adbfcd', label: '#5f7385' },
  linked: { wall: '#8fbac5', roof: '#e2f0f4', stroke: '#69959f', label: '#37596a' },
  active: { wall: '#0d8ba4', roof: '#d3ecf2', stroke: '#066d84', label: '#066d84' },
  project: { wall: '#a3c6ce', roof: '#e4f2f5', stroke: '#066d84', label: '#066d84' },
};

// Bauplätze für Gebäude aus der Datenbank, die im OpenStreetMap-Bestand nicht verortet sind.
const PROJECT_SLOTS = [
  { x: -54, y: 92, w: 34, d: 26 },
  { x: 26, y: 98, w: 32, d: 26 },
];

function BuildingVolume({ ring, levels, tone, status, dashed, label, hoverKey, interactive, hovered, onHover, onSelect }) {
  const base = ring.map(([x, y]) => project(x, y));
  const height = heightFor(levels);
  const roof = base.map((p) => ({ x: p.x, y: p.y - height }));
  const wallPoints = base.map((p, index) => {
    const nextIndex = (index + 1) % base.length;
    const next = base[nextIndex];
    const nextRoof = roof[nextIndex];
    return `${p.x.toFixed(1)},${p.y.toFixed(1)} ${next.x.toFixed(1)},${next.y.toFixed(1)} ${nextRoof.x.toFixed(1)},${nextRoof.y.toFixed(1)} ${roof[index].x.toFixed(1)},${roof[index].y.toFixed(1)}`;
  });
  const roofPoints = roof.map((p) => `${p.x.toFixed(1)},${p.y.toFixed(1)}`).join(' ');
  const center = roof.reduce(
    (acc, p) => ({ x: acc.x + p.x / roof.length, y: acc.y + p.y / roof.length }),
    { x: 0, y: 0 },
  );
  const xs = base.map((p) => p.x);
  const width = Math.max(...xs) - Math.min(...xs);

  return (
    <g
      role={interactive ? 'button' : undefined}
      tabIndex={interactive ? 0 : undefined}
      aria-label={interactive ? `${label}: Etagen und Grundriss öffnen` : undefined}
      className={interactive ? 'cursor-pointer focus:outline-none' : undefined}
      onMouseEnter={interactive ? () => onHover(hoverKey) : undefined}
      onMouseLeave={interactive ? () => onHover(null) : undefined}
      onClick={interactive ? () => onSelect() : undefined}
      onKeyDown={
        interactive
          ? (event) => {
              if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                onSelect();
              }
            }
          : undefined
      }
    >
      {wallPoints.map((points, index) => (
        <polygon key={index} points={points} fill={tone.wall} stroke={tone.stroke} strokeWidth="0.6" />
      ))}
      <polygon
        points={roofPoints}
        fill={tone.roof}
        stroke={hovered ? '#066d84' : tone.stroke}
        strokeWidth={hovered ? 1.6 : 1}
        strokeDasharray={dashed ? '5 3' : undefined}
      />
      {status ? (
        <circle cx={center.x} cy={center.y} r="4" fill={STATUS_COLOR[status] || STATUS_COLOR.unknown} stroke="#ffffff" strokeWidth="1.5" />
      ) : null}
      {width > 22 ? (
        <text
          x={center.x}
          y={center.y + 3.5}
          textAnchor="middle"
          fontSize="9"
          fontWeight={hovered ? 700 : 600}
          fill={tone.label}
          stroke="#ffffff"
          strokeWidth="2.8"
          paintOrder="stroke"
        >
          {label}
        </text>
      ) : null}
      <title>{dashed ? `${label} · Standort nicht im Lageplan hinterlegt` : label}</title>
    </g>
  );
}

function roadLabel(road) {
  let best = null;
  road.lines.forEach((line) => {
    const points = parsePoints(line).map(([x, y]) => project(x, y));
    for (let i = 0; i < points.length - 1; i += 1) {
      const length = Math.hypot(points[i + 1].x - points[i].x, points[i + 1].y - points[i].y);
      if (!best || length > best.length) best = { a: points[i], b: points[i + 1], length };
    }
  });
  if (!best || best.length < 110) return null;
  let angle = (Math.atan2(best.b.y - best.a.y, best.b.x - best.a.x) * 180) / Math.PI;
  if (angle > 90) angle -= 180;
  if (angle < -90) angle += 180;
  return { x: (best.a.x + best.b.x) / 2, y: (best.a.y + best.b.y) / 2, angle };
}

export default function CampusMap({ buildings = [], activeBuildingId, statusByBuilding = {}, onSelect }) {
  const [hovered, setHovered] = useState(null);

  const findMatch = (ref) =>
    buildings.find((building) => {
      const key = String(building.code || building.name || '').trim().toUpperCase();
      return key && key === String(ref).toUpperCase();
    });

  const entries = CAMPUS_BUILDINGS.map((entry) => ({ ...entry, ring: parsePoints(entry.poly), app: findMatch(entry.ref) }));
  const linkedIds = new Set(entries.filter((entry) => entry.app).map((entry) => entry.app.id));
  const unplaced = buildings.filter((building) => !linkedIds.has(building.id));

  const projectEntries = unplaced.slice(0, PROJECT_SLOTS.length).map((building, index) => ({
    ring: rectRing(PROJECT_SLOTS[index]),
    label: building.code || building.name,
    levels: building.floors_count,
    app: building,
    isProject: true,
  }));

  const placed = [...entries, ...projectEntries].sort((a, b) => southEdge(a.ring) - southEdge(b.ring));

  return (
    <svg
      viewBox="0 0 740 580"
      role="img"
      aria-label="Lageplan des h_da-Campus Stadtmitte mit dreidimensionalen Gebäuden"
      className="h-auto w-full min-w-[520px]"
    >
      <defs>
        <linearGradient id="bim-campus-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#f7fafb" />
          <stop offset="100%" stopColor="#e9f0f4" />
        </linearGradient>
        <clipPath id="bim-campus-frame">
          <rect x="0" y="0" width="740" height="536" />
        </clipPath>
      </defs>

      <rect width="740" height="580" fill="#fbfdfe" />

      <g clipPath="url(#bim-campus-frame)">
        <rect width="740" height="536" fill="url(#bim-campus-sky)" />

        {/* Straßen: Kontur und Fahrbahn */}
        {CAMPUS_ROADS.map((road) =>
          road.lines.map((line, index) => {
            const points = parsePoints(line).map(([x, y]) => project(x, y));
            const d = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
            return (
              <path
                key={`${road.name}-edge-${index}`}
                d={d}
                fill="none"
                stroke="#dde6ec"
                strokeWidth="14"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            );
          }),
        )}
        {CAMPUS_ROADS.map((road) =>
          road.lines.map((line, index) => {
            const points = parsePoints(line).map(([x, y]) => project(x, y));
            const d = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x.toFixed(1)} ${p.y.toFixed(1)}`).join(' ');
            return (
              <path
                key={`${road.name}-road-${index}`}
                d={d}
                fill="none"
                stroke="#ffffff"
                strokeWidth="11"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
            );
          }),
        )}

        {/* Campusgebäude */}
        {placed.map((entry) => {
          const app = entry.app;
          const isActive = Boolean(app) && app.id === activeBuildingId;
          const tone = entry.isProject ? TONE.project : isActive ? TONE.active : app ? TONE.linked : TONE.context;
          return (
            <BuildingVolume
              key={entry.isProject ? `project-${app.id}` : entry.ref}
              ring={entry.ring}
              levels={entry.isProject ? app.floors_count : entry.levels}
              tone={tone}
              status={app ? statusByBuilding[app.id] : null}
              dashed={Boolean(entry.isProject)}
              label={entry.label}
              hoverKey={entry.isProject ? `project-${app.id}` : entry.ref}
              interactive={Boolean(app)}
              hovered={hovered === (entry.isProject ? `project-${app.id}` : entry.ref)}
              onHover={setHovered}
              onSelect={() => app && onSelect(app)}
            />
          );
        })}

        {/* Straßennamen */}
        {CAMPUS_ROADS.map((road) => {
          const label = roadLabel(road);
          if (!label) return null;
          return (
            <text
              key={`label-${road.name}`}
              x={label.x}
              y={label.y - 6}
              transform={`rotate(${label.angle.toFixed(1)} ${label.x.toFixed(1)} ${label.y.toFixed(1)})`}
              textAnchor="middle"
              fontSize="8.5"
              letterSpacing="0.6"
              fill="#8ba0af"
              stroke="#ffffff"
              strokeWidth="3"
              paintOrder="stroke"
            >
              {road.name}
            </text>
          );
        })}

        {/* Nordpfeil */}
        <g transform="translate(700, 44)">
          <circle r="16" fill="#ffffff" stroke="#d6e1e9" />
          <polygon points="0,-9 4.5,5 0,2 -4.5,5" fill="#33475b" />
          <text x="0" y="-12" textAnchor="middle" fontSize="8.5" fontWeight="700" fill="#7d92a2">
            N
          </text>
        </g>

        {/* Maßstab 50 m */}
        <g transform="translate(56, 512)">
          <rect x="-6" y="-13" width="112" height="26" rx="6" fill="#ffffff" fillOpacity="0.85" />
          <line x1="0" y1="0" x2={50 * SCALE} y2="0" stroke="#7d92a2" strokeWidth="2" />
          <line x1="0" y1="-4" x2="0" y2="4" stroke="#7d92a2" strokeWidth="2" />
          <line x1={50 * SCALE} y1="-4" x2={50 * SCALE} y2="4" stroke="#7d92a2" strokeWidth="2" />
          <text x={50 * SCALE / 2} y="-5" textAnchor="middle" fontSize="9" fill="#6c8090">
            50 m
          </text>
        </g>
      </g>

      <text x="22" y="566" fontSize="9" fill="#93a6b4">
        {CAMPUS_ATTRIBUTION}
      </text>
    </svg>
  );
}