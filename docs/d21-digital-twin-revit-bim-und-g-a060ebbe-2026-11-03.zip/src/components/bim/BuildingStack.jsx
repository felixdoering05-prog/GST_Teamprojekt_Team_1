import { useState } from 'react';
import { isoPoint as iso, isoPolygon as pts } from '@/lib/iso';

const ORIGIN = { x: 400, y: 172 };
const P = (u, v) => iso(u, v, ORIGIN);

const FOOTPRINT = { u: 60, v: 36, w: 176, d: 116 };
const SLAB = 34;
const GAP = 10;

const TONE = {
  ok: { top: '#e1f6ec', right: '#46b183', left: '#2f9067' },
  warning: { top: '#fdf1d9', right: '#eaa63f', left: '#c9872b' },
  critical: { top: '#fbe4e4', right: '#e2635f', left: '#c44a47' },
  unknown: { top: '#eef2f6', right: '#c3ccd6', left: '#a9b6c2' },
};

export default function BuildingStack({
  building,
  floors = [],
  roomCountByFloor = {},
  statusByFloor = {},
  activeFloorId,
  onSelectFloor,
}) {
  const [hoveredId, setHoveredId] = useState(null);

  const { u, v, w, d } = FOOTPRINT;
  const a = P(u, v);
  const b = P(u + w, v);
  const c = P(u + w, v + d);
  const e = P(u, v + d);

  const stack = floors.map((floor, index) => ({ floor, lift: index * (SLAB + GAP) }));
  const totalHeight = Math.max(SLAB, stack.length * (SLAB + GAP) - GAP);

  return (
    <svg
      viewBox="0 0 760 440"
      role="img"
      aria-label={`Gebäudemodell ${building ? building.name : ''} mit anklickbaren Etagen`}
      className="h-auto w-full min-w-[520px]"
    >
      <defs>
        <linearGradient id="bim-stack-sky" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stopColor="#f8fbfc" />
          <stop offset="100%" stopColor="#e8f0f4" />
        </linearGradient>
      </defs>

      <rect width="760" height="440" fill="url(#bim-stack-sky)" />

      {/* Grundfläche und Schlagschatten */}
      <polygon points={pts([a, b, c, e])} fill="#bdcbd6" opacity="0.45" transform="translate(10,10)" />
      <polygon points={pts([a, b, c, e])} fill="#dbe5ec" stroke="#c2d0da" strokeWidth="1" />

      {stack.map(({ floor, lift }) => {
        const tone = TONE[statusByFloor[floor.id]] || TONE.unknown;
        const isActive = floor.id === activeFloorId;
        const isHovered = hoveredId === floor.id;
        const roof = [a, b, c, e].map((p) => ({ x: p.x, y: p.y - lift - SLAB }));
        const right = [b, c, { x: c.x, y: c.y - lift - SLAB }, { x: b.x, y: b.y - lift - SLAB }];
        const left = [c, e, { x: e.x, y: e.y - lift - SLAB }, { x: c.x, y: c.y - lift - SLAB }];
        const roofsPolygon = pts([...roof, roof[0]]);
        const labelY = (b.y + c.y) / 2 - lift - SLAB / 2;
        const startX = (b.x + c.x) / 2 + 7;
        const labelX = b.x + 30;

        return (
          <g
            key={floor.id}
            role="button"
            tabIndex={0}
            aria-label={`Etage ${floor.name} auswählen`}
            className="cursor-pointer focus:outline-none"
            onMouseEnter={() => setHoveredId(floor.id)}
            onMouseLeave={() => setHoveredId(null)}
            onFocus={() => setHoveredId(floor.id)}
            onBlur={() => setHoveredId(null)}
            onClick={() => onSelectFloor(floor.id)}
            onKeyDown={(event) => {
              if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                onSelectFloor(floor.id);
              }
            }}
          >
            <polygon points={pts(left)} fill={tone.left} stroke="#ffffff" strokeOpacity={isHovered ? 0.9 : 0.35} strokeWidth="1" />
            <polygon points={pts(right)} fill={tone.right} stroke="#ffffff" strokeOpacity={isHovered ? 0.9 : 0.35} strokeWidth="1" />
            <polygon
              points={pts(roof)}
              fill={tone.top}
              stroke={isActive ? '#066d84' : '#ffffff'}
              strokeOpacity={isActive ? 1 : 0.55}
              strokeWidth={isActive ? 1.8 : 1}
            />
            {isActive ? (
              <>
                <polygon points={roofsPolygon} fill="none" stroke="#066d84" strokeWidth="2.2" strokeLinejoin="round" />
                <polygon points={pts(right)} fill="none" stroke="#066d84" strokeWidth="2" />
                <polygon points={pts(left)} fill="none" stroke="#066d84" strokeWidth="2" />
              </>
            ) : null}

            <title>{`${floor.name} · ${roomCountByFloor[floor.id] || 0} Räume`}</title>

            <line x1={startX} y1={labelY} x2={labelX - 8} y2={labelY} stroke="#9db0be" strokeWidth="1" />
            <circle cx={startX} cy={labelY} r="2.4" fill={isActive ? '#066d84' : '#9db0be'} />
            <text
              x={labelX}
              y={labelY - 1}
              fontSize="12"
              fontWeight={isActive ? 700 : 600}
              fill={isActive ? '#066d84' : '#20323f'}
              stroke="#ffffff"
              strokeWidth="3"
              paintOrder="stroke"
            >
              {floor.name}
            </text>
            <text
              x={labelX}
              y={labelY + 12}
              fontSize="9.5"
              fill="#5b7183"
              stroke="#ffffff"
              strokeWidth="3"
              paintOrder="stroke"
            >
              {`${roomCountByFloor[floor.id] || 0} Räume`}
            </text>
          </g>
        );
      })}

      {/* Dachkante des obersten Geschosses */}
      {stack.length ? (
        <polyline
          points={pts(
            [a, b, c, e, a].map((p) => ({ x: p.x, y: p.y - totalHeight })),
          )}
          fill="none"
          stroke="#94a8b6"
          strokeWidth="1.2"
        />
      ) : null}

      <text
        x={(a.x + b.x + c.x + e.x) / 4}
        y={c.y + 34}
        textAnchor="middle"
        fontSize="11"
        fontWeight="700"
        fill="#20323f"
      >
        {building ? `${building.code || building.name} · ${building.name}` : ''}
      </text>
      <text x="22" y="424" fontSize="9.5" fill="#8fa4b3">
        Geschosshöhen und Volumen schematisch · keine IFC-Geometrie
      </text>
    </svg>
  );
}