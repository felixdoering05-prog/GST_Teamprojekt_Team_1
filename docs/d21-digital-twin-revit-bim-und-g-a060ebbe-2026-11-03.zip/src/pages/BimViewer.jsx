import { useState } from 'react';
import { Boxes, Info, Layers, RefreshCw } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import EmptyState from '@/components/EmptyState';
import StatusChip from '@/components/StatusChip';
import SourceBadge from '@/components/SourceBadge';
import CampusMap from '@/components/bim/CampusMap';
import BuildingStack from '@/components/bim/BuildingStack';
import BuildingPanel from '@/components/bim/BuildingPanel';
import RevitFloorPlan from '@/components/bim/RevitFloorPlan';
import RoomDetailPanel from '@/components/bim/RoomDetailPanel';
import { Button } from '@/components/ui/button';
import useD21Data from '@/hooks/useD21Data';
import { readingsForRoom, roomSeries, statusForRoom } from '@/lib/roomMetrics';
import { METRIC_KEYS, worstLevel } from '@/lib/metrics';
import { cn } from '@/lib/utils';

const LEGEND = [
  { level: 'ok', label: 'Im Sollbereich' },
  { level: 'warning', label: 'Warnung' },
  { level: 'critical', label: 'Kritisch' },
  { level: 'unknown', label: 'Keine Daten' },
];

const VIEWS = [
  { key: 'campus', label: 'Campus-Lageplan' },
  { key: 'model', label: 'Gebäudemodell' },
];

const HINTS = {
  campus:
    'Lageplan des h_da-Campus Stadtmitte aus OpenStreetMap-Daten. Gebäude mit Datenbestand sind hervorgehoben und lassen sich anklicken – die Etagen öffnen sich im Gebäudemodell.',
  model: 'Etage im Modell oder in der Liste auf der rechten Seite wählen. Geschosshöhen und Volumen sind schematisch.',
};

export default function BimViewer() {
  const data = useD21Data();
  const [view, setView] = useState('campus');
  const [buildingId, setBuildingId] = useState(null);
  const [floorId, setFloorId] = useState(null);
  const [selectedRoomId, setSelectedRoomId] = useState(null);

  const buildings = data.buildings.length ? data.buildings : data.building ? [data.building] : [];
  const activeBuilding = buildings.find((building) => building.id === buildingId) || buildings[0] || null;

  const buildingFloors = activeBuilding
    ? data.floors.filter((floor) => floor.building_id === activeBuilding.id)
    : [];
  const floors = buildingFloors.length ? buildingFloors : data.floors;
  const floorsDesc = [...floors].sort((a, b) => (b.level ?? 0) - (a.level ?? 0));
  const floorsAsc = [...floorsDesc].reverse();

  const activeFloor = floorsDesc.find((floor) => floor.id === floorId) || floorsDesc[0] || null;
  const activeFloorId = activeFloor ? activeFloor.id : null;
  const floorRooms = data.rooms
    .filter((room) => room.floor_id === activeFloorId)
    .sort((a, b) => String(a.room_code).localeCompare(String(b.room_code), 'de'));

  const readingsByRoom = {};
  data.rooms.forEach((room) => {
    readingsByRoom[room.id] = {
      readings: readingsForRoom(room, data.sensors, data.latest, data.thresholds),
      status: statusForRoom(room, data.sensors, data.latest, data.thresholds),
    };
  });

  const roomCountByFloor = {};
  const statusByFloor = {};
  floorsDesc.forEach((floor) => {
    const list = data.rooms.filter((room) => room.floor_id === floor.id);
    roomCountByFloor[floor.id] = list.length;
    statusByFloor[floor.id] = worstLevel(list.map((room) => readingsByRoom[room.id].status));
  });

  const statusByBuilding = {};
  buildings.forEach((building) => {
    const levels = data.rooms
      .filter((room) => room.building_id === building.id)
      .map((room) => readingsByRoom[room.id].status);
    statusByBuilding[building.id] = worstLevel(levels);
  });

  const selectedRoom = floorRooms.find((room) => room.id === selectedRoomId) || floorRooms[0] || null;
  const pointsByMetric = {};
  if (selectedRoom) {
    METRIC_KEYS.forEach((key) => {
      pointsByMetric[key] = roomSeries(selectedRoom, data.sensors, data.series, key);
    });
  }

  const selectBuilding = (building) => {
    setBuildingId(building.id);
    setView('model');
    setFloorId(null);
    setSelectedRoomId(null);
  };

  const selectFloor = (id) => {
    setFloorId(id);
    setSelectedRoomId(null);
  };

  if (data.loading) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-slate-200 border-t-primary" />
      </div>
    );
  }

  if (!data.rooms.length) {
    return (
      <div>
        <PageHeader title="BIM-Viewer" description="Lageplan, Gebäudemodell und Grundriss als Vorbereitung für das Revit-/IFC-Modell." />
        <EmptyState
          icon={Boxes}
          title="Keine Räume für die Darstellung vorhanden"
          description="Lageplan und Grundriss bauen auf den angelegten Gebäuden, Geschossen und Räumen auf. Legen Sie zuerst Räume unter „Gebäude & Räume“ an."
        />
      </div>
    );
  }

  const withRevit = data.rooms.filter((room) => room.revit_room_id).length;
  const revitOnFloor = floorRooms.filter((room) => room.revit_room_id).length;

  return (
    <div className="space-y-5">
      <PageHeader
        title="BIM-Viewer"
        description="Campus-Lageplan mit dreidimensionalen Gebäuden, anklickbare Etagen und schematische Grundrisse – die Bühne für das Revit-/IFC-Modell."
      >
        <Button variant="outline" size="sm" onClick={data.reload}>
          <RefreshCw className="mr-1.5 h-3.5 w-3.5" /> Aktualisieren
        </Button>
      </PageHeader>

      <div className="surface flex flex-wrap items-center gap-x-3 gap-y-1.5 px-5 py-3.5 text-xs text-muted-foreground">
        <Info className="h-4 w-4 shrink-0 text-cyan-700" />
        <span>
          <strong className="font-semibold text-foreground">{withRevit}</strong> von {data.rooms.length} Räumen mit
          Revit-Raum-ID
        </span>
        <span className="hidden h-3 w-px bg-border sm:block" />
        <span>Modellverweis: {data.building?.bim_model_ref || 'noch nicht eingetragen'}</span>
        <span className="ml-auto">
          <SourceBadge
            source={data.counts.demo > data.counts.real ? 'demo' : 'real'}
            labels={{ demo: 'Demo-Messwerte', real: 'Echte Messwerte' }}
          />
        </span>
      </div>

      <div className="grid gap-5 xl:grid-cols-3">
        <div className="surface overflow-x-auto xl:col-span-2">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-border px-4 py-3">
            <div className="inline-flex rounded-full bg-secondary p-1" role="tablist" aria-label="Ansicht wählen">
              {VIEWS.map((entry) => (
                <button
                  key={entry.key}
                  type="button"
                  role="tab"
                  aria-selected={view === entry.key}
                  onClick={() => setView(entry.key)}
                  className={cn(
                    'rounded-full px-3.5 py-1.5 text-xs font-medium transition-colors',
                    view === entry.key
                      ? 'bg-card text-foreground shadow-sm'
                      : 'text-muted-foreground hover:text-foreground',
                  )}
                >
                  {entry.label}
                </button>
              ))}
            </div>
            <div className="flex flex-wrap items-center gap-2.5">
              {LEGEND.map((item) => (
                <StatusChip key={item.level} level={item.level} label={item.label} size="xs" />
              ))}
            </div>
          </div>

          <div className="bg-gradient-to-b from-secondary/30 to-secondary/70 p-3 sm:p-4">
            {view === 'campus' ? (
              <CampusMap
                buildings={buildings}
                activeBuildingId={activeBuilding ? activeBuilding.id : null}
                statusByBuilding={statusByBuilding}
                onSelect={selectBuilding}
              />
            ) : (
              <BuildingStack
                building={activeBuilding}
                floors={floorsAsc}
                roomCountByFloor={roomCountByFloor}
                statusByFloor={statusByFloor}
                activeFloorId={activeFloorId}
                onSelectFloor={selectFloor}
              />
            )}
          </div>

          <div className="border-t border-border px-4 py-3 text-[11px] text-muted-foreground">{HINTS[view]}</div>
        </div>

        <BuildingPanel
          buildings={buildings}
          activeBuilding={activeBuilding}
          onSelectBuilding={selectBuilding}
          floors={floorsDesc}
          activeFloorId={activeFloorId}
          onSelectFloor={selectFloor}
          roomCountByFloor={roomCountByFloor}
          statusByFloor={statusByFloor}
        />
      </div>

      <div className="grid gap-5 xl:grid-cols-3">
        <div className="surface p-4 sm:p-5 xl:col-span-2">
          <div className="mb-3 flex flex-wrap items-start justify-between gap-3">
            <div>
              <h3 className="font-heading text-sm font-semibold text-foreground">
                Grundriss {activeFloor ? activeFloor.name : ''}
              </h3>
              <p className="text-[11px] text-muted-foreground">
                {floorRooms.length} Räume · Flächen aus den Stammdaten · Klick öffnet die Raumdetails
              </p>
            </div>
            <div className="flex flex-wrap items-center gap-1.5">
              <Layers className="mr-1 h-3.5 w-3.5 text-muted-foreground" />
              {floorsDesc.map((floor) => (
                <button
                  key={floor.id}
                  type="button"
                  onClick={() => selectFloor(floor.id)}
                  className={
                    floor.id === activeFloorId
                      ? 'rounded-full bg-primary px-3.5 py-1.5 text-xs font-medium text-primary-foreground'
                      : 'rounded-full bg-secondary px-3.5 py-1.5 text-xs font-medium text-muted-foreground transition-colors hover:text-foreground'
                  }
                >
                  {floor.name}
                </button>
              ))}
            </div>
          </div>

          <div className="overflow-x-auto rounded-xl border border-border">
            <RevitFloorPlan
              rooms={floorRooms}
              readingsByRoom={readingsByRoom}
              selectedRoomId={selectedRoom ? selectedRoom.id : null}
              onSelect={setSelectedRoomId}
              floorName={activeFloor ? activeFloor.name : ''}
              buildingCode={activeBuilding ? activeBuilding.code || activeBuilding.name : ''}
              revitCount={revitOnFloor}
            />
          </div>
        </div>

        <div>
          <RoomDetailPanel
            room={selectedRoom}
            floorLabel={selectedRoom ? (floorsDesc.find((floor) => floor.id === selectedRoom.floor_id) || {}).name : ''}
            readings={selectedRoom ? readingsByRoom[selectedRoom.id].readings : {}}
            sensors={data.sensors}
            pointsByMetric={pointsByMetric}
            thresholds={data.thresholds}
          />
        </div>
      </div>
    </div>
  );
}