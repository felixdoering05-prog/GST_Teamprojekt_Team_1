import { useEffect, useState } from 'react';
import { Lock, MessageSquareText, ShieldCheck, Sparkles } from 'lucide-react';
import PageHeader from '@/components/PageHeader';
import EmptyState from '@/components/EmptyState';
import { SelectField } from '@/components/Field';
import AssistantChat from '@/components/assistant/AssistantChat';
import { base44 } from '@/api/base44Client';

export default function BuildingAssistant() {
  const [buildings, setBuildings] = useState(null);
  const [buildingId, setBuildingId] = useState('');

  useEffect(() => {
    base44.entities.Building.list('-created_date', 20)
      .then((list) => {
        setBuildings(list || []);
        setBuildingId((current) => current || (list || [])[0]?.id || '');
      })
      .catch(() => setBuildings([]));
  }, []);

  if (buildings === null) {
    return (
      <div className="flex min-h-[50vh] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-slate-200 border-t-primary" />
      </div>
    );
  }

  if (!buildings.length) {
    return (
      <div>
        <PageHeader title="Gebäude-Assistent" description="Fragen zu freigegebenen Messwerten und Meldungen eines Gebäudes." />
        <EmptyState
          icon={MessageSquareText}
          title="Kein Gebäude vorhanden"
          description="Der Assistent arbeitet auf den Gebäuden der Anwendung. Legen Sie zuerst ein Gebäude unter „Gebäude & Räume“ an."
        />
      </div>
    );
  }

  const building = buildings.find((item) => item.id === buildingId) || buildings[0];
  const blocked = building?.ai_assistant_release === 'gesperrt';

  return (
    <div className="space-y-5">
      <PageHeader
        title="Gebäude-Assistent"
        description="Beantwortet Fragen zu den freigegebenen Messwerten und Grenzwertmeldungen des gewählten Gebäudes – als KI-generierte Zusammenfassung."
      />

      <div className="surface p-4 sm:p-5">
        <div className="grid gap-4 sm:grid-cols-2">
          <SelectField
            label="Gebäude"
            value={building.id}
            onChange={(event) => setBuildingId(event.target.value)}
            options={buildings.map((item) => ({
              value: item.id,
              label: `${item.name}${item.code && item.code !== item.name ? ` (${item.code})` : ''}`,
            }))}
            hint="Nur Daten dieses Gebäudes werden an den KI-Dienst übermittelt."
          />
          <div className="space-y-1.5">
            <p className="text-xs font-medium text-foreground">Freigabe für den Assistenten</p>
            <p
              className={
                blocked
                  ? 'inline-flex items-center gap-1.5 rounded-full bg-destructive/10 px-3 py-1.5 text-xs font-medium text-destructive'
                  : 'inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-1.5 text-xs font-medium text-emerald-700'
              }
            >
              {blocked ? <Lock className="h-3.5 w-3.5" /> : <ShieldCheck className="h-3.5 w-3.5" />}
              {blocked ? 'Gesperrt' : 'Freigegeben'}
            </p>
            <p className="text-[11px] text-muted-foreground">
              Die Freigabe wird je Gebäude in den Stammdaten gesetzt und serverseitig geprüft.
            </p>
          </div>
        </div>
      </div>

      <div className="surface flex flex-wrap items-start gap-4 border-l-4 border-l-cyan-500 p-5">
        <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-cyan-50 text-cyan-700">
          <Sparkles className="h-5 w-5" />
        </span>
        <div className="min-w-0 flex-1 text-sm text-muted-foreground">
          <h3 className="font-heading text-sm font-semibold text-foreground">Was übermittelt wird</h3>
          <p className="mt-1">
            Gebäudestammdaten (Name, Kürzel, Baujahr, Fläche, Geschosse, Nutzung), Kennzahlen der Messgrößen der letzten
            24 Stunden, die hinterlegten Grenzwerte sowie offene Grenzwertmeldungen. Keine Anmeldedaten, keine
            Kontaktdaten und keine Inhalte aus anderen Gebäuden.
          </p>
          <p className="mt-1.5">
            Der Modellaufruf erfolgt ausschließlich auf dem Server; im Browser liegt kein API-Schlüssel. Antworten sind
            eine Orientierung und müssen fachlich geprüft werden.
          </p>
        </div>
      </div>

      {blocked ? (
        <div className="surface flex items-start gap-3 p-5">
          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-xl bg-destructive/10 text-destructive">
            <Lock className="h-4 w-4" />
          </span>
          <div>
            <h3 className="font-heading text-sm font-semibold text-foreground">Daten für den Assistenten gesperrt</h3>
            <p className="mt-1 text-sm text-muted-foreground">
              Für {building.name} ist die Freigabe entzogen. Der Assistent beantwortet keine Fragen zu diesem Gebäude,
              solange die Freigabe in den Gebäudestammdaten auf „gesperrt“ steht.
            </p>
          </div>
        </div>
      ) : (
        <AssistantChat building={building} />
      )}
    </div>
  );
}