import { createClientFromRequest } from 'npm:@base44/sdk@0.8.54';
import {
  collectBuildingContext,
  buildAssistantPrompt,
  MAX_QUESTION_LENGTH,
} from '../../shared/buildingAssistant.ts';

const AI_UNAVAILABLE_HINT =
  'Der integrierte KI-Dienst (InvokeLLM) hat nicht geantwortet. Nächster Schritt: Verbindung der Integration im Dashboard prüfen und die Anfrage erneut senden.';

export default async function (req) {
  try {
    const base44 = createClientFromRequest(req);
    const user = await base44.auth.me().catch((e) => (e.status === 401 ? null : Promise.reject(e)));
    if (!user) {
      return Response.json(
        { code: 'unauthorized', message: 'Bitte melden Sie sich an, um den Gebäude-Assistenten zu nutzen.' },
        { status: 401 },
      );
    }

    const body = await req.json().catch(() => ({}));
    // Nur echte Zeichenketten werden akzeptiert - Objekte oder Filterausdrücke als Gebäude-ID werden verworfen.
    const buildingId = typeof body.building_id === 'string' ? body.building_id.trim() : '';
    const question =
      typeof body.question === 'string' ? body.question.replace(/[\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim() : '';

    if (!buildingId) {
      return Response.json({ code: 'missing_building', message: 'Es wurde kein Gebäude ausgewählt.' }, { status: 400 });
    }
    if (!question) {
      return Response.json({ code: 'missing_question', message: 'Bitte geben Sie eine Frage ein.' }, { status: 400 });
    }
    if (question.length > MAX_QUESTION_LENGTH) {
      return Response.json(
        {
          code: 'question_too_long',
          message: `Die Frage ist zu lang. Bitte kürzen Sie sie auf ${MAX_QUESTION_LENGTH} Zeichen.`,
        },
        { status: 400 },
      );
    }

    // Das Gebäude muss existieren und für den Assistenten freigegeben sein.
    const building = await base44.entities.Building.get(buildingId).catch((e) =>
      e.status === 404 ? null : Promise.reject(e),
    );
    if (!building) {
      return Response.json(
        {
          code: 'building_not_available',
          message: 'Für diese Gebäude-ID liegen keine freigegebenen Daten vor.',
        },
        { status: 404 },
      );
    }
    if (building.ai_assistant_release === 'gesperrt') {
      return Response.json(
        {
          code: 'not_released',
          message: `Die Daten des Gebäudes ${building.name || building.code || ''} sind für den Assistenten nicht freigegeben.`,
        },
        { status: 403 },
      );
    }

    const context = await collectBuildingContext(base44, building);
    const prompt = buildAssistantPrompt(context, question);

    let raw;
    try {
      raw = await base44.asServiceRole.integrations.Core.InvokeLLM({ prompt });
    } catch (error) {
      return Response.json(
        { code: 'ai_unavailable', message: 'Die KI-Schnittstelle ist derzeit nicht verfügbar.', hint: AI_UNAVAILABLE_HINT },
        { status: 502 },
      );
    }

    const answer = typeof raw === 'string' ? raw.trim() : String(raw || '').trim();
    if (!answer) {
      return Response.json(
        { code: 'empty_answer', message: 'Es wurde keine Antwort erzeugt.', hint: AI_UNAVAILABLE_HINT },
        { status: 502 },
      );
    }

    return Response.json({
      answer,
      building: {
        id: building.id,
        name: building.name || '',
        code: building.code || null,
      },
      period: context.period,
      data_quality: context.data_quality,
      notice: context.data_quality.has_enough_data
        ? null
        : `Es liegen nur ${context.data_quality.measurements} Messwerte im Zeitraum vor – die Aussagekraft ist begrenzt.`,
    });
  } catch (error) {
    return Response.json(
      { code: 'internal_error', message: 'Die Anfrage konnte nicht verarbeitet werden.' },
      { status: 500 },
    );
  }
}